﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gestion_Projet
{
    public class Films
    {
        private int Titre;
        private int Date_Sortie;
        private int Realisateur;
        private int Image;
        private int ID_Film;

        public int id_film
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int date_sortie
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int image
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int realisateur
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int titre
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void Affiche_Films()
        {
            throw new System.NotImplementedException();
        }
    }
}