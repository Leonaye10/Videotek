﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gestion_Projet
{
    public class Categorie
    {
        private int ID_Cate;
        private int Nom;

        public int id_cate
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int nom
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void Affiche_Cate()
        {
            throw new System.NotImplementedException();
        }
    }
}