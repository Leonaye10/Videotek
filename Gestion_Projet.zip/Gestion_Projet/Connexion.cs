﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gestion_Projet
{
    public class Connexion
    {
        private int Log;
        private int Mdp;

        public int log
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int mdp
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void connexion()
        {
            throw new System.NotImplementedException();
        }
    }
}