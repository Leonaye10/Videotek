﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gestion_Projet
{
    public class Membre
    {
        private int ID;
        private int Nom;
        private int Prenom;
        private int Adresse;
        private int Phone;

        public int id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int nom
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int prenom
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int phone
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int adresse
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public void Inscription()
        {
            throw new System.NotImplementedException();
        }
    }
}